document.addEventListener('DOMContentLoaded', (event) => {
    document.getElementById('result').textContent = "Udało się prawidłowo dodać skrypt"
});


const handleClick = () => {
    alert('Udało się poprawnie podpiąć skrypt')
}