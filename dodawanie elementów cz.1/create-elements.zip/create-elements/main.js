document.addEventListener('DOMContentLoaded', (event) => {
    addName();
    editText();
    addDate();
    addSimpleBlockWithText();
    addImageToDocument();
    addButtonWithAlert();
});


const addName = () => {
}

const editText = () => {
}

const addDate = () => {
    //
}

const addSimpleBlockWithText = () =>{

}


const addImageToDocument = () =>{

}

const handleClick = () => {
    alert('Udało się poprawnie podpiąć skrypt')
}

const addButtonWithAlert = () =>{

}
